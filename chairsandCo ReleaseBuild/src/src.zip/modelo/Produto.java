package modelo;

import java.io.Serializable;
import java.util.Objects;
import chairsandco.*;

public class Produto implements Serializable{
    
    private Integer codigo;
    private String tipo;
    private int madeira, couro, pano, metal, plastico; //quanto de cada material é feita a cadeira

    public Produto(Cadeira ctc){
        this.madeira = ctc.madeira;
        this.couro = ctc.couro;
        this.pano = ctc.pano;
        this.metal = ctc.metal;
        this.plastico = ctc.plastico;
        this.tipo = ctc.tipo;
        
    }

    public Produto() {}
    
    public String getTipo() {return tipo;}
    public void setTipo(String toadd) {tipo = toadd;}
    
    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }
    
    public int getMadeira(){return madeira;}
    public int getCouro(){return couro;}
    public int getPano(){return pano;}
    public int getMetal(){return metal;}
    public int getPlastico(){return plastico;}
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.codigo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Produto other = (Produto) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        return true;
    }
}
