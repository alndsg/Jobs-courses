
package modelo;

import java.util.ArrayList;
import java.util.List;


public class Dados {
    public static List<SCliente> listaCliente = new ArrayList<>();
    public static List<Produto> listaProduto = new ArrayList<>();
    public static List<Venda> listaVenda = new ArrayList<>();
}
